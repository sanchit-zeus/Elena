from django.apps import AppConfig


class ElenaAppConfig(AppConfig):
    name = 'elena_app'
